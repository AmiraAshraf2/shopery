const Joi = require("joi");

exports.productSchema = Joi.object({
  name: Joi.string().required(),
  price: Joi.number().required()
});