const Category = require("../models/category.model");

exports.getAll = async (req, res) => {
  const data = await Category.find();
  res.status(200).json(data);
};

exports.create = async (req, res) => {
  const category = await Category.create(req.body);
  res.status(201).json(category);
};

exports.delete = async (req, res) => {
  await Category.findByIdAndDelete(req.params.id);
  res.status(200).json({ message: "Category was deleted successful" });
};