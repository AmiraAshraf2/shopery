const Product = require("../models/Product.model");

exports.getAll = async (req, res) => {
  const products = await Product.find();
  res.status(200).json(products);
};

exports.create = async (req, res) => {
  const product = await Product.create({
    ...req.body,
    createdBy: req.user.id
  });
  res.status(201).json(product);
};

exports.uploadImage = async (req, res) => {
  const product = await Product.findById(req.params.id);
  product.image = req.file.path;
  await product.save();

  res.status(201).json(product);
};