const express = require("express");
const router = express.Router();
const auth = require("../middlewares/auth.middleware");
const productController = require("../controllers/product.controller");
const role = require("../middlewares/role.middleware")
const upload = require("../middlewares/upload.middleware");

router.get("/", productController.getAll);

router.post("/", auth, role("admin"), productController.create);

router.post(
  "/:id/upload-image",
  auth,
  role("admin"),
  upload.single("image"),
  productController.uploadImage
);

module.exports = router;

