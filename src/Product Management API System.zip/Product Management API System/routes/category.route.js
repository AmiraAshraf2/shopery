const express = require("express");
const router = express.Router();
const role = require("../middlewares/role.middleware")
const categoryController = require("../controllers/category.controller")

router.get("/", categoryController.getAll);

router.post("/", categoryController.create);

router.delete("/id", role("admin"), categoryController.delete);

module.exports = router;