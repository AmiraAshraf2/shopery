const mongoose = require("mongoose");

const categorySchema = new mongoose.Schema({
    name:{
        type: String,
        required: true,
        unique: true
    },
    description:{
        type: String,
        minlength: 3
    },
    createdAt: {
    type: Date,
    default: Date.now
  }
})

module.exports = mongoose.model("Categories", categorySchema);