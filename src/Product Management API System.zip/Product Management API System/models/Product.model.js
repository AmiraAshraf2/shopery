const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true,
        unique: true,
        minlength: 3
    },
    description:{
        type: String,
        required: true,
        minlength: 3
    },
    price:{
        type: Number,
        required: true
    },
    image:{
        type: String
    },
    categoryId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Category"
    },
    createdBy:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    createdAt:{
        type: Date,
        default: Date.now
    }

})