const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors")
const dotenv = require("dotenv");
dotenv.config({ path: "./confg.env" });
const categoryRoute = require("./routes/category.route")
const authRouters = require("./routes/auth.routes")
const prodouctRouters = require("./routes/product.route")
const errorhandler = require("./middlewares/error.middleware")


const app = express();



app.use(express.json());


app.use(cors());
app.use("/category", categoryRoute);
app.use("/api", authRouters);
app.use("/prodouct", prodouctRouters);





app.use(errorhandler);




async function dbConnection() {
    try {
        await mongoose.connect(process.env.DB_URL);
        console.log("connected!");
        
    } catch (error) {
        console.log(error);
        
    }
}

dbConnection();



app.listen(process.env.PORT,()=>{
    console.log(`Server is Running at port ${process.env.PORT}`);
    
})